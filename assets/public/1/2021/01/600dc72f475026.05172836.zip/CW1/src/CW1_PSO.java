import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Properties;

import net.sourceforge.jswarm_pso.Neighborhood1D;
import net.sourceforge.jswarm_pso.FitnessFunction;
import net.sourceforge.jswarm_pso.Particle;
import net.sourceforge.jswarm_pso.Swarm;
import java.lang.Math;

public class CW1_PSO {
	private static double R = 5.12;

	/**	
	 * 					|Scenario 1	|Scenario 2	| 
	 * numParticlces	|	1000	|	200		|
	 * numIters			|	1000	|	50		|
	 * neighWeight		|	0.6		|	0.3		|
	 * inertiaWeight	|	0.6		|	1.5		|
	 * personalWeight	|	2.3		|	0.9		|
	 * globalWeight		|	0.1		|	0.3		|
	 * maxMinVelocity	|	0.025	|	0.025	|
	 * **/
	
	
	private int numParticles = 100;
	private int numIters = 100;
	private double neighWeight = 0.3f; 
	private double inertiaWeight = 1.5f; 
	private double personalWeight = 0.9f;
	private double globalWeight = 0.3; 
	private double maxMinVelocity = 0.025f;

	private static String FILE_PATH = "C:/Users/Connor/Downloads/bio spreadsheets/PSO/";
	private static final int NUM_ITERATIONS = 30;
	
	public void parseParams(String paramFile) {
		try {
			Properties properties = new Properties();
			properties.load(new FileInputStream(paramFile));

			Enumeration enuKeys = properties.keys();
			while (enuKeys.hasMoreElements()) {
				String key = (String) enuKeys.nextElement();
				String value = properties.getProperty(key);
	
				if(key.equals("numParticles")) {
					numParticles = Integer.parseInt(value);
				} else if(key.equals("neighWeight")) {
					neighWeight = Double.parseDouble(value);
				} else if(key.equals("inertiaWeight")) {
					inertiaWeight = Double.parseDouble(value);
				} else if(key.equals("personalWeight")) {
					personalWeight = Double.parseDouble(value);
				} else if(key.equals("globalWeight")) {
					globalWeight = Double.parseDouble(value);
				} else if(key.equals("maxMinVelocity")) {
					maxMinVelocity = Double.parseDouble(value);
				} else if(key.equals("numIters")) {
					numIters = Integer.parseInt(value);
				} else {
					System.out.println("Unknown parameter "+key);
				} 
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public double run() {
		// Create a swarm (using 'MyParticle' as sample particle 
		// and 'MyFitnessFunction' as finess function)
		Swarm swarm = new Swarm(numParticles
			, new MyParticle()
			, new MyFitnessFunction());
		// Set position (and velocity) constraints. 
		// i.e.: where to look for solutions

		// Use neighborhood
		Neighborhood1D neigh = new Neighborhood1D(numParticles / 10, true);
		swarm.setNeighborhood(neigh);
		swarm.setNeighborhoodIncrement(neighWeight);

		// Set weights of velocity update formula
		swarm.setInertia(inertiaWeight); // Previous velocity weight
                swarm.setParticleIncrement(personalWeight); // Personal best weight
                swarm.setGlobalIncrement(globalWeight); // Global best weight

		// Set limits to velocity value
		swarm.setMaxMinVelocity(maxMinVelocity);

		// Set max and min positions
		swarm.setMaxPosition(+R);
		swarm.setMinPosition(-R);

		// Optimize a few times
		for( int i = 0; i < numIters; i++ ) { 
			swarm.evolve();
			//showGenerations(i,swarm.getBestFitness());
			//System.out.println(swarm.toStringStats());
		}
		//System.out.println(swarm.toStringStats());
		return swarm.getBestFitness();
	}

	
	
	public static void main(final String[] args) {
		CW1_PSO alg = new CW1_PSO();
//		if(args.length>0) {
//			alg.parseParams(args[0]);
//		}
		
		
		//showIterations(alg);
		//testTime(alg);
		//testSingleVar(alg);
		testCurrentValues(alg);
		//testParticlesIterations(alg);
		//testParams(alg);
		//testSpeed(alg);
	}
	
	
	
	private static void showIterations(CW1_PSO alg) {
		File f = new File(FILE_PATH + "allIterations10k.csv");
		
		try {
			f.createNewFile(); 
			FileWriter fw = new FileWriter(f,true);
			for(int i = 0; i < NUM_ITERATIONS; i++) {
				fw.write(i + "," + alg.run() + "\n");
				
			}
			fw.close();
		}catch(Exception e) {}
	}
	
	
	private static void showGenerations(long generation, double stats) {
		File f = new File(FILE_PATH + "generationStats.csv");
		
		try {
			if(!f.exists())
				f.createNewFile();
			System.out.println(stats);
			FileWriter fw = new FileWriter(f,true);
			fw.write(generation + "," + stats + "\n");
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private static void testTime(CW1_PSO alg) {
		double startTime = System.nanoTime();
		for(int i = 0; i < NUM_ITERATIONS; i++) {
			alg.run();
		}
		double endTime = System.nanoTime();
		System.out.println(((endTime - startTime) / NUM_ITERATIONS) / 1000000000);
	}
	
	private static void testCurrentValues(CW1_PSO alg) {
		double total = 0f;
		
		double min = 100;
		double max = 0;
		
		for(int i = 0; i < NUM_ITERATIONS; i++) {
			double thisRun = alg.run();
			total += thisRun;
			if(thisRun < min)
				min = thisRun;
			if(thisRun > max)
				max = thisRun;
		}
		total /= NUM_ITERATIONS;
		System.out.println("Average: " + total);
		System.out.println("Min Value: " + min);
		System.out.println("Max Value: " + max);
		
	}
	
	public static void testParticlesIterations(CW1_PSO alg) {
		double total = 0;
		FILE_PATH = "C:/Users/Connor/Downloads/bio spreadsheets/PSO/particles2.csv";
		File f = new File(FILE_PATH);
		try {
			if(!f.exists())
				f.createNewFile();

			FileWriter fw = new FileWriter(f,false);
			fw.write("INITIAL VALUES,inertia, global, neighbour,personal\n");
			fw.write("," + alg.inertiaWeight + "," + alg.globalWeight + "," + alg.neighWeight + ","+ alg.personalWeight +"\n\n");
			fw.write("particles,iterations,min\n");
			fw.close(); 

			}catch (Exception e) {
				// TODO: handle exception
			}
		try {
			FileWriter fw = new FileWriter(f,true);
			

			int[] values = new int[] {10,20,50,100,200,500,1000,2000,5000};
			
			for(int v : values) {
				total = 0;
				alg.numParticles = v;
				alg.numIters = 10000 / v;
				for(int i = 0; i < NUM_ITERATIONS; i++) {
					total += alg.run();
				}
				total /= NUM_ITERATIONS;
				fw.write(alg.numParticles + "," + alg.numIters + "," + total + "\n");
			}
			fw.close();
			}catch (Exception e) {
				// TODO: handle exception
			}
	}
	
	public static void testSingleVar(CW1_PSO alg) {
		double total = 0;
		FILE_PATH = "C:/Users/Connor/Downloads/bio spreadsheets/PSO_1M/inertiaResults.csv";
		File f = new File(FILE_PATH);
		try {
			if(!f.exists())
				f.createNewFile();

			FileWriter fw = new FileWriter(f,false);
			fw.write("INITIAL VALUES,inertia, global, neighbour,personal\n");
			fw.write("," + alg.inertiaWeight + "," + alg.globalWeight + "," + alg.neighWeight + ","+ alg.personalWeight +"\n\n");
			fw.write("inertia weight, min\n");
			fw.close(); 
			}catch (Exception e) {
				// TODO: handle exception
			}
		try {
			FileWriter fw = new FileWriter(f,true);
			
			for(alg.inertiaWeight = 0.1f; alg.inertiaWeight <= 2f; alg.inertiaWeight += 0.1f) {
				total = 0;	
				for(int i = 0; i < NUM_ITERATIONS; i++) {
						total += alg.run();
					}
				total /= NUM_ITERATIONS;
				fw.write(alg.inertiaWeight + ","+ total +  "\n");
				//System.out.println(alg.globalWeight);
				
			}
			
			fw.close();
			}catch (Exception e) {
				// TODO: handle exception
			}
	}
	
	public static void testSpeed(CW1_PSO alg) {
		double total = 0;
		FILE_PATH = "C:/Users/Connor/Downloads/bio spreadsheets/PSO_1M/velocityResults.csv";
		File f = new File(FILE_PATH);
		try {
			if(!f.exists())
				f.createNewFile();

			FileWriter fw = new FileWriter(f,false);
			fw.write("personal, global, neighbour, inertia\n");
			fw.write(alg.personalWeight + "," + alg.globalWeight + "," + alg.neighWeight + "," + alg.inertiaWeight +"\n\n");
			fw.write("velocity, min\n");
			fw.close(); 
			}catch (Exception e) {
				// TODO: handle exception
			}
		try {
			FileWriter fw = new FileWriter(f,true);
			
			for(alg.maxMinVelocity = 0f; alg.maxMinVelocity <= 0.3f; alg.maxMinVelocity += 0.005f) {
				total = 0;	
				for(int i = 0; i < NUM_ITERATIONS; i++) {
						total += alg.run();
					}
				total /= NUM_ITERATIONS;
				fw.write(alg.maxMinVelocity + ","+ total +  "\n");
				//System.out.println(alg.globalWeight);	
			}
			
			fw.close();
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	
	
	public static void testParams(CW1_PSO alg) {
		double total = 0;
		FILE_PATH = "C:/Users/Connor/Downloads/bio spreadsheets/PSO_1M/personalGlobal.csv";
		File f = new File(FILE_PATH);
		try {
			if(!f.exists())
				f.createNewFile();

			FileWriter fw = new FileWriter(f,false);
			fw.write("personal weight, global weight, min\n");
			fw.close(); 
			}catch (Exception e) {
				// TODO: handle exception
			}
		try {
			FileWriter fw = new FileWriter(f,true);
			
			for(alg.personalWeight = 0f; alg.personalWeight <= 2.2f; alg.personalWeight += 0.3f) {
				for(alg.globalWeight = 0f; alg.globalWeight <= 2.2f; alg.globalWeight += 0.3f) {
						total = 0;
						for(int i = 0; i < NUM_ITERATIONS; i++) {
							total += alg.run();
						}
						total /= NUM_ITERATIONS;
						fw.write(alg.personalWeight + "," + alg.globalWeight + "," + total +  "\n");
						//System.out.println(alg.globalWeight);
					
				}
			} 
			fw.close();
			}catch (Exception e) {
				// TODO: handle exception
			}
	}
}
