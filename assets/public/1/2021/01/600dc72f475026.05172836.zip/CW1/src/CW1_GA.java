import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Properties;


import static java.lang.Math.PI;
import static java.lang.Math.cos;
import static io.jenetics.engine.EvolutionResult.toBestPhenotype;

import io.jenetics.DoubleGene;
import io.jenetics.SinglePointCrossover;
import io.jenetics.UniformCrossover;
import io.jenetics.MeanAlterer;
import io.jenetics.TournamentSelector;
import io.jenetics.EliteSelector;
import io.jenetics.Mutator;
import io.jenetics.GaussianMutator;
import io.jenetics.Optimize;
import io.jenetics.Phenotype;
import io.jenetics.engine.Codecs;
import io.jenetics.engine.Engine;
import io.jenetics.engine.EvolutionStatistics;
import io.jenetics.stat.DoubleMomentStatistics;
import io.jenetics.util.DoubleRange;

public class CW1_GA {
	private static final double A = 10;
	private static final double R = 5.12;
	private static final int N = 10;

	private static final int TEST_ITERATIONS = 25;
	private static final int NUM_FITNESS_CALLS = 1000000;
	
	/**
	 * 					|Scenario 1	|Scenario 2	|
	 * popSize			|	50		|	500		|
	 * numSurvivors		|	1		|	1		|
	 * tournamentSize	|	2		|	10		|
	 * probMutation		|	0.08	|	0.07	|
	 * probCrossover	|	1		|	1		|
	 * numIters			|	20000	|	20		|
	 */
	
	private int popSize = 1000;
	private int numSurvivors = 2;
	private int tournamentSize = 5;
	private double probMutation = 0.15;
	private double probCrossover = 0.95;
	private int numIters = 1000;

	//set to output folder.
	private static String filePath = "C:/Users/Connor/Downloads/bio spreadsheets/GA_1M/second2";
	
	private static double fitness(final double[] x) {
		double value = A*N;
		for (int i = 0; i < N; ++i) {
			value += x[i]*x[i] - A*cos(2.0*PI*x[i]);
		}

		return value;
	}

	public void parseParams(String paramFile) {
		try {
			Properties properties = new Properties();
			properties.load(new FileInputStream(paramFile));

			Enumeration enuKeys = properties.keys();
			while (enuKeys.hasMoreElements()) {
				String key = (String) enuKeys.nextElement();
				String value = properties.getProperty(key);
	
				if(key.equals("popSize")) {
					popSize = Integer.parseInt(value);
				} else if(key.equals("numSurvivors")) {
					numSurvivors = Integer.parseInt(value);
				} else if(key.equals("tournamentSize")) {
					tournamentSize = Integer.parseInt(value);
				} else if(key.equals("probMutation")) {
					probMutation = Double.parseDouble(value);
				} else if(key.equals("probCrossover")) {
					probCrossover = Double.parseDouble(value);
				} else if(key.equals("numIters")) {
					numIters = Integer.parseInt(value);
				} else {
					System.out.println("Unknown parameter "+key);
				} 
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public double run() {
		final Engine<DoubleGene, Double> engine = Engine
			.builder(
				CW1_GA::fitness,
				// Codec for 'x' vector.
				Codecs.ofVector(DoubleRange.of(-R, R), N))
			.populationSize(popSize)
			.optimize(Optimize.MINIMUM)
			.survivorsSize(numSurvivors)
			.survivorsSelector(new EliteSelector<>(numSurvivors))
			.offspringSelector(new TournamentSelector<>(tournamentSize))
			.alterers(
				//new Mutator<>(probMutation),
				new GaussianMutator<>(probMutation),
				//new UniformCrossover<>(probCrossover))
				//new SinglePointCrossover<>(probCrossover))
				new MeanAlterer<>(probCrossover))
			.build(); 
 
		final EvolutionStatistics<Double, ?>
			statistics = EvolutionStatistics.ofNumber();

		final Phenotype<DoubleGene, Double> best = engine.stream()
			.limit(numIters)
			.peek(statistics)
			// Uncomment the following line to get updates at each iteration
			//.peek(r -> showGenerations(r.getGeneration(),r.getBestFitness()))
			.collect(toBestPhenotype());

		//System.out.println(statistics);
		//return best.getFitness();
		return best.getFitness();
	}
	
	
	public static void main(final String[] args) {

		CW1_GA alg = new CW1_GA();

		//showGenerations(alg);
		//testTime(alg);
		testCurrentValues(alg);
		//runPopItr(alg);
		//runValues(alg);
	}
	
	
	
	private static void showIterations(CW1_GA alg) {
		File f = new File(filePath + "iterations.csv");
		
		try {
			f.createNewFile(); 
			FileWriter fw = new FileWriter(f,true);
			for(int i = 0; i < TEST_ITERATIONS; i++) {
				fw.write(i + "," + alg.run() + "\n");
				
			}
			fw.close();
		}catch(Exception e) {}
	}
	
	
	private static void showGenerations(long generation, double stats) {
		File f = new File(filePath + "generations.csv");
		
		try {
			if(!f.exists())
				f.createNewFile();
			System.out.println(stats);
			FileWriter fw = new FileWriter(f,true);
			fw.write(generation + "," + stats + "\n");
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private static void testTime(CW1_GA alg) {
		double startTime = System.nanoTime();
		for(int i = 0; i < TEST_ITERATIONS; i++) {
			alg.run();
		}
		double endTime = System.nanoTime();
		System.out.println(((endTime - startTime) / TEST_ITERATIONS) / 1000000000);
	}
	
	private static void testCurrentValues(CW1_GA alg) {
		double totalFitness = 0f;
		for(int j = 0; j < TEST_ITERATIONS; j++) {
			totalFitness += alg.run();
		}
		System.out.println(totalFitness / TEST_ITERATIONS);
	}
	
	/**
	 * Function to compare population size, iterations, tournament size 
	 * Outputs to csv in filePath/pop_itr_tourn.csv
	 * 
	 * @param alg
	 */
	private static void runPopItr(CW1_GA alg) {
		filePath += "population_iteration_tournSize3.csv";
		File f = createFile("pop size, iterations, tournament, min");
		
		try {
			FileWriter fw = new FileWriter(f,true);
			
			int[] popSizeArr = new int[] {50,100,200,500,1000,2000,5000,10000,20000,50000};
			int[] tournaments = new int[] {2,5,10};
			for(int tourn : tournaments) {
				alg.tournamentSize = tourn;
				for(int pop : popSizeArr) {
					int itr = NUM_FITNESS_CALLS / pop;
					
					double total = 0;
					alg.popSize = pop;
					alg.numIters = itr;

					for(int i = 0; i < TEST_ITERATIONS; i++) {
						total += alg.run();
					}
					
					fw.write(pop + "," + itr + "," + +tourn + ","+ (total / TEST_ITERATIONS) + "\n");
					System.out.println(pop + "," + itr + "," + (total / TEST_ITERATIONS));
				}
			}
			fw.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	private static File createFile(String title) {
		File f = new File(filePath);
		try {
			if(!f.exists())
				f.createNewFile();
			
			//overwrite anything that currently exists
			FileWriter fw = new FileWriter(f,false);
			
			//set up page
			fw.write(title + "\n");
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return f;
	}
	
	/**
	 * Function to run a parameter sweep on a single variable.
	 * 
	 * @param alg
	 */
	private static void runValues(CW1_GA alg) {
		//update pop size & iterations, output best.
		String variable = "survivors";
		filePath += variable + ".csv";
		File f = createFile(variable + ",fitness");
		
		try {
			FileWriter fw = new FileWriter(f,true);
			
			//INPUT VALUES
			int[] values = new int[] {1,2,3,4,5,10,25,50,100,500};
			
			
			for(int value : values) {
				double totalFitness = 0;
				
				//VARIABLE TO CHANGE PER TEST
				alg.numSurvivors = value;
				
				for(int j = 0; j < TEST_ITERATIONS; j++) {
					totalFitness += alg.run();
				}
				double avgFitness = totalFitness / TEST_ITERATIONS;
				fw.write(value + "," + avgFitness + "\n");
				System.out.println(avgFitness);
			}
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
}
